#SXD20|20010|50505|50538|2016.10.13 20:35:53|projectmanager|0|6|86|
#TA cms`26`16384|db`3`16384|ftp`23`16384|host`7`16384|projects`27`16384|users`0`16384
#EOH

#	TC`cms`utf8_general_ci	;
CREATE TABLE `cms` (
  `p_id` int(11) NOT NULL,
  `cms_type` varchar(40) NOT NULL,
  `cms_login` varchar(20) NOT NULL,
  `cms_password` varchar(20) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`cms`utf8_general_ci	;
INSERT INTO `cms` VALUES 
(1,'Bitrix','admin','JVi%WJkVTCfSnRSK'),
(2,'Bitrix','admin','cgflbk[yfN159'),
(3,'Webmanager','admin','Sd5bWhq6NTSyJKdJ'),
(4,'Bitrix','admin','bitrixadmin777'),
(5,'Webmanager','itmanager','And123A'),
(6,'Bitrix','admin','nrfxbr87'),
(7,'Webmanager','designprof','NHR5866324'),
(8,'Bitrix','admin','bitrixadmin777'),
(9,'Bitrix','admin','nu2uAzUwyy'),
(10,'Bitrix','admin','bitrixadmin777'),
(11,'Bitrix','admin','bitrixadmin777'),
(12,'Bitrix','stolitsa','ievbrncoinmi'),
(13,'Webmanager','test1','be$5a*hbh7'),
(14,'Webmanager','dolagrodolina2015','dolagrodolina2015'),
(15,'Bitrix','admin','11111'),
(16,'Bitrix','admin','bitrixadmin777'),
(17,'Bitrix','admin','6MSp7WuvRTQuRTOg'),
(19,'Bitrix','kgs2015 ','m5R2nKD8HR'),
(24,'Bitrix','admin','birixadmin777'),
(29,'Webmanager','Igor','1234567'),
(30,'Bitrix','admin','bitrixadmin777'),
(31,'Webmanager','admin','Sd5bWhq6NTSyJKdJ'),
(33,'Webmanager','main','02040402'),
(34,'Bitrix','admin','bitrixadmin777'),
(35,'Bitrix','admin','OsjarHidel{ogEsjucs'),
(37,'Webmanager','test','test')	;
#	TC`db`utf8_general_ci	;
CREATE TABLE `db` (
  `p_id` int(11) NOT NULL,
  `db_name` varchar(20) NOT NULL,
  `db_login` varchar(20) NOT NULL,
  `db_password` varchar(20) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`db`utf8_general_ci	;
INSERT INTO `db` VALUES 
(3,'test','test','test'),
(10,'ak','admin','B4SEI59Y'),
(11,'ak','admin','B4SEI59Y')	;
#	TC`ftp`utf8_general_ci	;
CREATE TABLE `ftp` (
  `p_id` int(11) NOT NULL,
  `ftp_server` varchar(100) NOT NULL,
  `ftp_login` varchar(20) NOT NULL,
  `ftp_password` varchar(20) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`ftp`utf8_general_ci	;
INSERT INTO `ftp` VALUES 
(2,'193.41.4.170','novinskiy','lCpzRXe5'),
(3,'ez1318.mirohost.net','comforttown','I5I7khXglb'),
(4,'193.41.4.170','agrostory','eqQngj1l'),
(5,'econia.ftp.ukraine.com.ua','econia_ftp','bCGAzJW5'),
(6,'ez488.mirohost.net','nissanftp','7gPwZJU2nA'),
(7,'fvh53.mirohost.net','designprofK','yQTwZEIM'),
(8,'ef1458.mirohost.net','naturalica','a56KnIZp'),
(9,'193.41.4.170','pokrova','J7rxrPeS'),
(10,'193.41.4.170','ak','vfsCJesp'),
(11,'ak.opt-fashion.com','ak','vfsCJesp'),
(13,'dolina.ua','dolina','1d2rOoOP'),
(14,'dolagro.ru','dolagro','JkYm5tJt'),
(16,'ef1343.mirohost.net','superstep','czyhdNxR'),
(19,'193.41.4.170','kmbsale','kuvWcbYq'),
(24,'193.41.4.170','biopel','QEiTKMg2'),
(29,'193.41.4.70','termolan','maiR4nuju1'),
(30,'193.41.4.170','peletta-new','ctnEV6Kc'),
(31,'fvh2.mirohost.net','centralpark','UBBuTG4D'),
(33,'printogram.com.ua','printogram','xuSh1re2ie'),
(34,'194.0.187.206','ftpuser','ig7EPOlpHOLv1AIysff3'),
(35,'amstor.com.ua','amstor','u9BEEPJp'),
(36,'193.41.4.70:2222','optfashion','eokum3go'),
(37,'intspace.com.ua','intspace','du8ohj9OPhoh')	;
#	TC`host`utf8_general_ci	;
CREATE TABLE `host` (
  `p_id` int(11) NOT NULL,
  `hosting` varchar(100) NOT NULL,
  `host_login` varchar(50) NOT NULL,
  `host_password` varchar(50) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`host`utf8_general_ci	;
INSERT INTO `host` VALUES 
(3,'https://control.mirohost.net/','ct_site_2016','x11*rfOZFK^gnlM'),
(7,'https://control.mirohost.net/','fitoutcomua','tnXafECuCw'),
(9,'https://193.41.4.170:1500','pokrova','J7rxrPeS'),
(10,'193.41.4.170','ak','vfsCJesp'),
(11,'https://193.41.4.170:1500','ak','vfsCJesp'),
(12,'https://uashared02.twinservers.net:2083/','stolitsa','$T}9d}5l.w*d'),
(32,'http://cpanel.radiotech.hk','radihhk1','rad86181')	;
#	TC`projects`utf8_general_ci	;
CREATE TABLE `projects` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `production` tinyint(1) NOT NULL,
  `img` varchar(40) DEFAULT NULL,
  `descr` text,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8	;
#	TD`projects`utf8_general_ci	;
INSERT INTO `projects` VALUES 
(1,'Eldorado Club',0,\N,'','club.eldorado.com.ua'),
(2,'Novynski',0,\N,'','http://novynskyi.com/'),
(3,'Comforttown',0,\N,'','http://comforttown.com.ua/'),
(4,'Agrostory',0,\N,'','http://agrostory.com/'),
(5,'Econia',0,\N,'','http://www.econia.com.ua/'),
(6,'Nissan Kiyavto',0,\N,'','http://nissan.kiyauto.com.ua/'),
(7,'Designprof',0,\N,'','http://designprof.com.ua/'),
(8,'Naturalica',0,\N,'','http://naturalica.com.ua/'),
(9,'Pokrova',0,\N,'user2 bitrix\r\nl: admin_pokrova \r\np: xKp|#lmoua ','http://fondpokrov.org.ua/ru/'),
(11,'Aliance',0,\N,'','http://ak.opt-fashion.com/'),
(12,'Stolica',0,\N,'','http://stolitsa2000.com.ua/'),
(13,'Dolina',0,\N,'','http://www.dolina.ua/'),
(14,'Dolagro',0,\N,'','http://www.dolagro.ru/'),
(15,'Smart Holding',0,\N,'','http://www.smart-holding.com/ru/'),
(16,'Superstep',0,\N,'Ð”Ð¾Ð±Ð°Ð²Ð»ÑÑ‚ÑŒ Ñ†Ð²ÐµÑ‚Ð° Ñ‚Ð¾Ð²Ð°Ñ€Ð¾Ð² ÐºÐ°Ñ‚Ð°Ð»Ð¾Ð³Ð° /superstep.ua/bitrix/php_interface Ñ„Ð°Ð¹Ð» init.php','http://superstep.ua/'),
(17,'Smart Energy',0,\N,'','http://smart-energy.com.ua/ru/'),
(19,'Kmb-sale',0,\N,'','kmb-sale.com'),
(24,'Biopel',0,\N,'','http://biopel.opt-fashion.com/'),
(29,'Termolan',0,\N,'','http://www.termolan.com.ua/'),
(30,'Peletta',0,\N,'','http://peletta-new.opt-fashion.com/ru/'),
(31,'Centralpark',0,\N,'','http://centralpark.com.ua/'),
(32,'Radiotech',0,\N,'Ð§ÐµÑ€ÐµÐ· Ñ„Ñ‚Ð¿ Ð½Ðµ ÐºÐ¾Ð½ÐµÐºÑ‚Ð¸Ñ‚, Ñ†Ð¼ÑÐºÐ¸ Ð½ÐµÑ‚ - Ð»ÐµÐ½Ð´Ð¸Ð½Ð³','http://radiotech.hk/'),
(33,'Printogram',0,\N,'','printogram.com.ua'),
(34,'Creditwest',0,\N,'','https://www.creditwest.ua/uk/'),
(35,'Amstor',0,\N,'','http://amstor.com.ua/'),
(36,'E-space',0,\N,'','http://e-space.opt-fashion.com/'),
(37,'Intspace',0,\N,'ÐŸÐ¾Ñ‡Ñ‚Ð° Ð½Ð° ÐºÐ¾Ñ‚Ð¾Ñ€ÑƒÑŽ Ð¿Ñ€Ð¸Ñ…Ð¾Ð´ÑÑ‚ Ð¿Ð¸ÑÑŒÐ¼Ð° intspace.reply@gmail.com (intspaceREPLY),  Ñ Ð½ÐµÐµ Ñ€ÐµÐ´Ð¸Ñ€ÐµÐºÑ‚ Ð½Ð° @intspace.com.ua','http://www.intspace.com.ua/')	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(10) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
